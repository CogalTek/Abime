document.getElementById('searchBtn').addEventListener('click', () => {
    const elementId = document.getElementById('elementId').value;
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, {action: "findElementById", elementId: elementId});
    });
});
