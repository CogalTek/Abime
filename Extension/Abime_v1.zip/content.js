function createPopup(content) {

    // Supprimer l'ancien popup s'il existe
    const oldPopup = document.getElementById('customPopup');
    if (oldPopup) {
        oldPopup.remove();
    }

    // Créer un nouvel élément de popup
    const popup = document.createElement('div');
    popup.id = 'customPopup';
    popup.style.position = 'fixed';
    popup.style.bottom = '20px';
    popup.style.right = '20px';
    popup.style.padding = '10px';
    popup.style.background = 'white';
    popup.style.border = '1px solid #ddd';
    popup.style.zIndex = '10000'; // Assurez-vous qu'il est bien visible
    popup.innerText = content;

    // Ajouter le popup au document
    document.body.appendChild(popup);

    // Supprimer le popup après 3 secondes
    setTimeout(() => {
        if (document.body.contains(popup)) {
            document.body.removeChild(popup);
        }
    }, 3000);
}

function handleMouseOver(event) {

    const ar = [
        {
            name: "BA11-ADHERENTS MUTUELLE",
            desc: "requetes des mutuelle"
        },
        {
            name: "BA12-LISTE SALARIE (adresse et enfant)",
            desc: "liste des salarie avec leurs enfant et adresse"
        },
        {
            name: "BA13-MEDAILLES",
            desc: "liste des medailles"
        },
    ]


    if (event.target.id.includes('ListingURE_detailView_listColumn')) {
        for (let i of ar) {
            if (event.target.innerText === i.name) {
                createPopup(i.desc);
                break;
            }
        }
    }
}

function handleMouseEnter(event) {

    var name = "iframe4660-837469";

    createPopup(`${event.target.id}`);
    if (event.target.id === name) {
        createPopup(`✅`);
        console.log(event.target)
        var iframeDocument = event.target.contentDocument || event.target.contentWindow.document;
        console.log(iframeDocument)
        iframeDocument.addEventListener('mouseover', handleMouseOver)
    }




    if (event.target.tagName.toLowerCase() === 'tr') {
        // Afficher l'ID de la tr dans la console
        console.log('ID de la tr survolée:', event.target.id);
        if (event.target.id.includes("ListingURE_detailView_listNode")) {
            createPopup(`Nom valide ✅: ${document.getElementById(event.target.id).innerText}`);
        }
    }
}

function checkIframOrigin(iframename) {
    try {
        var iframe = window.frames[iframename];
        var iframeLocation = iframe.location.href;
        console.log("same origin, access granted")
        var _iframe = document.getElementsByName(iframename)[0];
        _iframe.addEventListener('load', function() {
            var iframeDocument = _iframe.contentDocument || _iframe.contentWindow.document;
            console.log(iframeDocument);
            iframeDocument.addEventListener('mouseover', handleMouseEnter)  
            createPopup('✅');
        });
    } catch (e) {
        console.log("pas d'acces", e)
        // afficher une popup d'erreur
    }
}

if (window.location.href === 'https://pleiades-bo.fr.lactadom.ad/BOE/BI') {
    console.log("test start");
    checkIframOrigin("servletBridgeIframe")
}
